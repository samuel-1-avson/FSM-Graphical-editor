from PyQt5.QtCore import QObject, pyqtSignal, QThread, QTime, QTimer, Qt, QMetaObject, pyqtSlot, Q_ARG
import json
import re
import logging
import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold # For safety settings
import google.api_core.exceptions # For Gemini API exceptions
from PyQt5.QtGui import QMovie # Add QMovie for potential animation
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTextEdit, QHBoxLayout, QLineEdit, QPushButton, QLabel, QStyle
logger = logging.getLogger(__name__)

class ChatbotWorker(QObject):
    responseReady = pyqtSignal(str, bool)
    errorOccurred = pyqtSignal(str)
    statusUpdate = pyqtSignal(str)

    def __init__(self, api_key, model_name="gemini-1.5-flash-latest", parent=None):
        super().__init__(parent)
        self.api_key = api_key
        self.model_name = model_name
        self.client: genai.GenerativeModel | None = None
        self.conversation_history = []
        self.current_diagram_context_json_str: str | None = None
        self._current_processing_had_error = False
        self._is_stopped = False
        self._initialize_client()
        logger.info(f"ChatbotWorker initialized (Gemini API Key {'SET' if api_key else 'NOT SET'}).")

    def _initialize_client(self):
        if self.api_key:
            try:
                genai.configure(api_key=self.api_key)
                safety_settings = {
                    HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
                    HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
                    HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
                    HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
                }
                self.client = genai.GenerativeModel(self.model_name, safety_settings=safety_settings)
                logger.info(f"Gemini client initialized for model {self.model_name}.")
                # Don't emit errorOccurred here, let process_message handle it if client is None
            except Exception as e:
                self.client = None
                error_msg = f"Failed to initialize Gemini client: {e}"
                logger.error(error_msg, exc_info=True)
                # self.errorOccurred.emit(error_msg) # Avoid emitting error from init if possible
        else:
            self.client = None
            logger.info("Gemini client not initialized (no API key).")

    @pyqtSlot(str)
    def set_api_key_slot(self, api_key: str):
        logger.info(f"WORKER: set_api_key_slot called (new key {'SET' if api_key else 'NOT SET'}).")
        self.api_key = api_key
        self._initialize_client()

    @pyqtSlot(str)
    def set_diagram_context_slot(self, diagram_json_str: str):
        if not diagram_json_str:
            logger.debug(f"WORKER: Setting diagram context to None (received empty string).")
            self.current_diagram_context_json_str = None
        else:
            logger.debug(f"WORKER: Setting diagram context. Length: {len(diagram_json_str)}")
            self.current_diagram_context_json_str = diagram_json_str

    @pyqtSlot(str, bool)
    def process_message_slot(self, user_message: str, force_fsm_generation: bool):
        if self._is_stopped:
            logger.info("WORKER_PROCESS: Worker is stopped, ignoring message.")
            return

        logger.info(f"WORKER_PROCESS: process_message_slot CALLED for: '{user_message[:50]}...' (force_fsm_generation={force_fsm_generation})")
        self._current_processing_had_error = False

        if not self.api_key or not self.client:
            error_msg = "Gemini API key not set or client not initialized. Please set it in AI Assistant Settings."
            logger.warning("process_message: %s", error_msg)
            self.errorOccurred.emit(error_msg)
            self.statusUpdate.emit("Status: API Key required.")
            self._current_processing_had_error = True
            return

        if self._is_stopped:
            logger.info("WORKER_PROCESS: Worker stopped before API call.")
            return

        self.statusUpdate.emit("Status: Thinking...")

        is_fsm_generation_attempt = False
        if force_fsm_generation:
            is_fsm_generation_attempt = True
        else:
            keywords_for_generation = [
                "generate fsm", "create fsm", "generate an fsm model",
                "generate state machine", "create state machine", "design state machine",
                "model fsm", "model state machine",
                "draw fsm", "draw state machine", "make an fsm", "fsm design for",
                "/generate_fsm"
            ]
            user_msg_lower = user_message.lower()
            is_fsm_generation_attempt = any(re.search(r'\b' + re.escape(keyword) + r'\b', user_msg_lower) for keyword in keywords_for_generation)

        is_embedded_code_request = False
        if not is_fsm_generation_attempt:
            embedded_keywords = [
                "arduino", "raspberry pi", "rpi", "esp32", "stm32",
                "microcontroller", "embedded c", "gpio", "pwm", "adc",
                "i2c", "spi", "sensor code", "actuator code", "mechatronics code",
                "robotics code", "control system code", "firmware snippet"
            ]
            user_msg_lower_for_embedded = user_message.lower()
            if any(re.search(r'\b' + re.escape(keyword) + r'\b', user_msg_lower_for_embedded) for keyword in embedded_keywords):
                is_embedded_code_request = True
                logger.debug(f"WORKER_PROCESS: Detected embedded code request keywords in '{user_message[:50]}...'")

        logger.debug(f"WORKER_PROCESS: is_fsm_generation_attempt = {is_fsm_generation_attempt} for '{user_message[:50]}...'")

        system_prompt_content = "You are a helpful assistant for designing Finite State Machines."
        if self.current_diagram_context_json_str:
            try:
                diagram = json.loads(self.current_diagram_context_json_str)
                if "error" not in diagram:
                    state_names = [s.get('name', 'UnnamedState') for s in diagram.get('states', [])]
                    num_transitions = len(diagram.get('transitions', []))
                    if state_names:
                        context_summary = (
                            f" The current diagram has states: {', '.join(state_names[:5])}"
                            f"{' and others' if len(state_names) > 5 else ''}."
                            f" It has {num_transitions} transition(s)."
                        )
                        system_prompt_content += context_summary
                    else:
                        system_prompt_content += " The current diagram is empty."
            except json.JSONDecodeError:
                logger.warning("WORKER_PROCESS_CTX_ERROR: JSONDecodeError processing diagram context.", exc_info=True)
                system_prompt_content += " (Error reading diagram context in worker)."
            except Exception as e_ctx:
                logger.error(f"WORKER_PROCESS_CTX_ERROR: Error processing diagram context: {e_ctx}", exc_info=True)
                system_prompt_content += " (Issue with diagram context string)."
        else:
             system_prompt_content += " No diagram context was provided for this request."

        if is_fsm_generation_attempt:
            system_prompt_content += (
                " When asked to generate an FSM, you MUST respond with ONLY a valid JSON object that directly represents the FSM data. "
                "The root of the JSON should be an object. "
                "This JSON object should have a top-level string key 'description' for a brief FSM description (e.g., 'A simple traffic light controller.'). "
                "It MUST have a key 'states' which is a list of state objects. "
                "Each state object MUST have a 'name' (string, required and unique for the FSM). "
                "Optional state object keys: 'is_initial' (boolean, default false), 'is_final' (boolean, default false), "
                "'entry_action' (string), 'during_action' (string), 'exit_action' (string), "
                "and a 'properties' object (optional) which can contain 'color' (string, CSS hex e.g., '#RRGGBB'). "
                "The JSON object MUST also have a key 'transitions' which is a list of transition objects. "
                "Each transition object MUST have 'source' (string, an existing state name from the 'states' list) and 'target' (string, an existing state name from the 'states' list). "
                "Optional transition object keys: 'event' (string), 'condition' (string), 'action' (string), "
                "'control_offset_x' (number, for curve horizontal bend), 'control_offset_y' (number, for curve vertical shift from midpoint), "
                "and a 'properties' object (optional) for 'color'. "
                "Optionally, include a top-level key 'comments' which is a list of comment objects. Each comment object can have 'text' (string), 'x' (number, optional for layout hint), 'y' (number, optional for layout hint), 'width' (number, optional). "
                "Do not include any state positions (x, y, width, height for states) in the JSON, as the application will handle layout. "
                "Absolutely no other text, greetings, explanations, or markdown formatting like ```json should be outside or inside this single JSON object response. The response must be parseable by json.loads()."
            )
        else:
            if is_embedded_code_request:
                system_prompt_content += (
                    " You are also an expert assistant for mechatronics and embedded systems programming. "
                    "If the user asks for Arduino code, structure it with `void setup() {}` and `void loop() {}`. "
                    "If for Raspberry Pi, provide Python code, using `RPi.GPIO` for GPIO tasks if appropriate, or other common libraries like `smbus` for I2C. "
                    "For other microcontrollers like ESP32 or STM32, provide C/C++ code in a typical embedded style (e.g., using Arduino framework for ESP32 if common, or HAL/LL for STM32 if specified). "
                    "Provide clear, well-commented code snippets. "
                    "If including explanations, clearly separate the code block using markdown (e.g., ```c or ```python or ```cpp). "
                    "Focus on the specific request and aim for functional, copy-pasteable code where possible. "
                    "For general mechatronics algorithms (e.g., PID, kinematics), pseudocode or Python is often suitable unless a specific language is requested."
                )
            else:
                 system_prompt_content += " For general conversation, provide helpful and concise answers."

        # --- Start: Corrected API Content Construction ---
        api_contents = []

        # 1. Add System Prompt and a dummy model response to ensure role alternation
        if system_prompt_content:
            api_contents.append({"role": "user", "parts": [{"text": system_prompt_content}]})
            api_contents.append({"role": "model", "parts": [{"text": "Understood. I will follow these instructions carefully."}]})

        # 2. Add Conversation History
        # self.conversation_history is assumed to be already in alternating user/model roles.
        history_context_limit = -6 # Max 3 user/model message pairs
        if self.conversation_history:
            for msg in self.conversation_history[history_context_limit:]:
                if isinstance(msg, dict) and "role" in msg and "parts" in msg:
                    # Ensure history roles are valid and append
                    if msg["role"] in ["user", "model"]:
                        # Critical check for alternation with the last item in api_contents
                        if api_contents and api_contents[-1]["role"] == msg["role"]:
                            logger.warning(f"Correcting role sequence: inserting dummy opposite role before history message: {msg['parts'][0]['text'][:30]}...")
                            # Insert a dummy message of the opposite role
                            dummy_role = "model" if msg["role"] == "user" else "user"
                            api_contents.append({"role": dummy_role, "parts": [{"text": "Okay."}]})
                        api_contents.append(msg)
                    else:
                        logger.warning(f"Skipping malformed history message with invalid role: {msg.get('role')}")
                else:
                    logger.warning(f"Skipping malformed history message: {msg}")
        
        # 3. Add Current User Message
        # Ensure current user message follows a "model" role if api_contents is not empty
        if api_contents and api_contents[-1]["role"] == "user":
            logger.warning("Correcting role sequence: last message was 'user', adding dummy model ack before current user message.")
            api_contents.append({"role": "model", "parts": [{"text": "Acknowledged."}]})
        
        api_contents.append({"role": "user", "parts": [{"text": user_message}]})
        # --- End: Corrected API Content Construction ---
        
        generation_config = genai.types.GenerationConfig(
            temperature=0.7,
        )
        if is_fsm_generation_attempt:
            generation_config.response_mime_type = "application/json"
            logger.info("WORKER_PROCESS: Requesting JSON object format from Gemini.")

        try:
            if self._is_stopped:
                logger.info("WORKER_PROCESS: Worker stopped just before creating completion.")
                return
            
            generation_args = {
                "contents": api_contents, # Use the correctly constructed api_contents
                "generation_config": generation_config,
            }
            
            logger.debug(f"WORKER_PROCESS: Sending to Gemini. Contents (first part text len, role):")
            for i, item_content in enumerate(api_contents): # Log the final contents for debugging
                first_part_text = item_content.get("parts", [{}])[0].get("text", "")
                preview = first_part_text[:80].replace('\n', ' ') + ('...' if len(first_part_text) > 80 else '')
                logger.debug(f"  Part {i}: Role '{item_content.get('role', 'N/A')}', Text Len: {len(first_part_text)}, Preview: '{preview}'")

            response = self.client.generate_content(**generation_args)

            if self._is_stopped:
                logger.info("WORKER_PROCESS: Worker stopped during/after API call, discarding response.")
                return

            ai_response_content = ""
            if response.candidates and response.candidates[0].content and response.candidates[0].content.parts:
                ai_response_content = response.candidates[0].content.parts[0].text
            elif hasattr(response, 'text'): # Fallback for older/different response structures
                ai_response_content = response.text
            else:
                feedback = response.prompt_feedback if hasattr(response, 'prompt_feedback') else "No feedback."
                finish_reason = response.candidates[0].finish_reason if response.candidates else "Unknown reason."
                error_msg = f"Gemini response was empty or blocked. Finish Reason: {finish_reason}. Feedback: {feedback}"
                logger.error(error_msg)
                if hasattr(response, 'prompt_feedback') and response.prompt_feedback:
                    block_reason_msg = getattr(response.prompt_feedback, 'block_reason_message', None) # Safe access
                    if block_reason_msg: error_msg += f" Block Reason Message: {block_reason_msg}"
                    for rating in response.prompt_feedback.safety_ratings:
                        if rating.blocked:
                             error_msg += f" Safety Blocked: Category {rating.category}, Probability {rating.probability.name}"
                self.errorOccurred.emit(error_msg)
                self._current_processing_had_error = True
                return

            # Add original user message and AI response to history
            # Ensure we use the original user_message, not one potentially modified with system prompt
            self.conversation_history.append({"role": "user", "parts": [{"text": user_message}]})
            self.conversation_history.append({"role": "model", "parts": [{"text": ai_response_content}]})
            logger.debug("WORKER_PROCESS: AI response received and added to history.")
            self.responseReady.emit(ai_response_content, is_fsm_generation_attempt)

        except google.api_core.exceptions.ServiceUnavailable as e:
            logger.error("Gemini API Connection/Service Error: %s", str(e)[:200], exc_info=True)
            self.errorOccurred.emit(f"API Connection Error: {str(e)[:200]}")
            self._current_processing_had_error = True
        except google.api_core.exceptions.ResourceExhausted as e:
            logger.error("Gemini Rate Limit Exceeded: %s", str(e)[:200], exc_info=True)
            self.errorOccurred.emit(f"Rate Limit Exceeded: {str(e)[:200]}")
            self._current_processing_had_error = True
        except (google.api_core.exceptions.PermissionDenied, google.auth.exceptions.RefreshError, google.auth.exceptions.DefaultCredentialsError) as e:
            logger.error("Gemini Authentication/Permission Error: %s", str(e)[:200], exc_info=True)
            self.errorOccurred.emit(f"Authentication Error (Invalid API Key?): {str(e)[:200]}")
            self.statusUpdate.emit("Status: API Key Error.")
            self._current_processing_had_error = True
        except google.api_core.exceptions.GoogleAPIError as e: 
            error_detail = str(e)
            if hasattr(e, 'message') and e.message: error_detail = e.message
            logger.error("Gemini API Error: %s - %s", type(e).__name__, error_detail[:250], exc_info=True)
            self.errorOccurred.emit(f"Google API Error: {type(e).__name__} - {error_detail[:250]}")
            self._current_processing_had_error = True
        except (genai.types.BlockedPromptException, genai.types.StopCandidateException) as e: 
            error_msg = f"Gemini content generation blocked or stopped: {e}"
            logger.error("WORKER_PROCESS: %s", error_msg, exc_info=True)
            self.errorOccurred.emit(error_msg)
            self._current_processing_had_error = True
        except Exception as e:
            error_msg = f"Unexpected error in AI worker: {type(e).__name__} - {str(e)[:150]}"
            logger.error("WORKER_PROCESS: %s", error_msg, exc_info=True)
            self.errorOccurred.emit(error_msg)
            self._current_processing_had_error = True
        finally:
            if not self._current_processing_had_error and self.client and not self._is_stopped:
                self.statusUpdate.emit("Status: Ready.")

    @pyqtSlot()
    def clear_history_slot(self):
        self.conversation_history = []
        logger.info("Conversation history cleared.")
        self.statusUpdate.emit("Status: Chat history cleared.")

    @pyqtSlot()
    def stop_processing_slot(self):
        logger.info("WORKER: stop_processing_slot called.")
        self._is_stopped = True
class AIChatUIManager(QObject):
    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.mw = main_window

        self.ai_chat_display: QTextEdit = None
        self.ai_chat_input: QLineEdit = None
        self.ai_chat_send_button: QPushButton = None
        self.ai_chat_status_label: QLabel = None
        self.original_send_button_icon: QIcon = None # To store original icon
        self.thinking_spinner_movie: QMovie | None = None

        self._connect_actions_to_manager_slots()
        self._connect_ai_chatbot_signals()

    # ... (create_dock_widget_contents)
    def create_dock_widget_contents(self) -> QWidget:
        ai_chat_widget = QWidget()
        ai_chat_layout = QVBoxLayout(ai_chat_widget)
        ai_chat_layout.setContentsMargins(5,5,5,5); ai_chat_layout.setSpacing(5)

        self.ai_chat_display = QTextEdit(); self.ai_chat_display.setReadOnly(True)
        self.ai_chat_display.setObjectName("AIChatDisplay"); 
        self.ai_chat_display.setPlaceholderText("AI chat history will appear here...")
        ai_chat_layout.addWidget(self.ai_chat_display, 1)

        input_layout = QHBoxLayout()
        self.ai_chat_input = QLineEdit(); self.ai_chat_input.setObjectName("AIChatInput")
        self.ai_chat_input.setPlaceholderText("Type your message to the AI...")
        self.ai_chat_input.returnPressed.connect(self.on_send_ai_chat_message)
        input_layout.addWidget(self.ai_chat_input, 1)

        self.ai_chat_send_button = QPushButton() # Icon will be set in update_status_display
        self.original_send_button_icon = get_standard_icon(QStyle.SP_ArrowRight, "SndAI") # Store it
        self.ai_chat_send_button.setIcon(self.original_send_button_icon)

        self.ai_chat_send_button.setObjectName("AIChatSendButton")
        self.ai_chat_send_button.setToolTip("Send message to AI")
        self.ai_chat_send_button.setFixedWidth(40) 
        self.ai_chat_send_button.clicked.connect(self.on_send_ai_chat_message)
        input_layout.addWidget(self.ai_chat_send_button)
        ai_chat_layout.addLayout(input_layout)

        self.ai_chat_status_label = QLabel("Status: Initializing...")
        self.ai_chat_status_label.setObjectName("AIChatStatusLabel")
        ai_chat_layout.addWidget(self.ai_chat_status_label)
        
        # Attempt to load a spinner GIF (ensure you have one in resources or path)
        # Example: Create a 'spinner.gif' and add to resources.qrc: <file>spinner.gif</file>
        # For simplicity, we'll fall back to text if GIF isn't found/working.
        # spinner_path = ":/icons/spinner.gif" # Assuming it's in resources under /icons
        # if QFile.exists(spinner_path):
        #     self.thinking_spinner_movie = QMovie(spinner_path)
        #     self.thinking_spinner_movie.setScaledSize(QSize(16, 16)) # Adjust size as needed
        # else:
        #     logger.warning("Spinner GIF for AI thinking state not found at :/icons/spinner.gif")
        #     self.thinking_spinner_movie = None


        return ai_chat_widget

    @pyqtSlot(str)
    def update_status_display(self, status_text: str):
        if not self.ai_chat_status_label: return
        self.ai_chat_status_label.setText(status_text)
        
        is_thinking = any(s in status_text.lower() for s in ["thinking...", "sending...", "generating...", "processing...", "initializing..."])
        is_key_req = any(s in status_text.lower() for s in ["api key required", "api key error", "api key cleared"])
        is_inactive = "inactive" in status_text.lower()
        is_general_error = ("error" in status_text.lower() or "failed" in status_text.lower()) and not is_key_req
        is_offline = "offline" in status_text.lower()
        is_ready = "ready" in status_text.lower() and not is_key_req and not is_thinking and not is_general_error and not is_offline and not is_inactive
        
        base_style = f"font-size: {APP_FONT_SIZE_SMALL}; padding: 2px 4px; border-radius: 3px;"

        if is_key_req or is_inactive:
            self.ai_chat_status_label.setStyleSheet(f"{base_style} color: white; background-color: {COLOR_ACCENT_ERROR}; font-weight: bold;")
        elif is_offline:
            self.ai_chat_status_label.setStyleSheet(f"{base_style} color: {COLOR_TEXT_PRIMARY}; background-color: {COLOR_ACCENT_WARNING};")
        elif is_general_error:
            self.ai_chat_status_label.setStyleSheet(f"{base_style} color: white; background-color: {COLOR_ACCENT_ERROR}; font-weight: bold;")
        elif is_thinking: 
            self.ai_chat_status_label.setStyleSheet(f"{base_style} color: {COLOR_TEXT_PRIMARY}; background-color: {QColor(COLOR_ACCENT_SECONDARY).lighter(130).name()}; font-style: italic;")
        elif is_ready: 
            self.ai_chat_status_label.setStyleSheet(f"{base_style} color: white; background-color: {COLOR_ACCENT_SUCCESS};")
        else: 
            self.ai_chat_status_label.setStyleSheet(f"{base_style} color: {COLOR_TEXT_SECONDARY}; background-color: {COLOR_BACKGROUND_MEDIUM};")

        can_send_message = is_ready 

        if self.ai_chat_send_button:
            self.ai_chat_send_button.setEnabled(can_send_message)
            if is_thinking:
                self.ai_chat_send_button.setText("...") # Simple text indicator
                self.ai_chat_send_button.setIcon(QIcon()) # Hide icon
                # if self.thinking_spinner_movie:
                #     self.ai_chat_send_button.setIcon(QIcon()) # Clear static icon
                #     # This part is tricky for QPushButton, usually QLabel is used for QMovie
                #     # For simplicity, we'll stick to text change or disable.
                #     # To show movie on button, you might need a custom button or overlay.
                #     # self.thinking_spinner_movie.start() # No direct way to put movie on QPushButton icon
                # else:
                #     self.ai_chat_send_button.setText("...") # Fallback text
            else:
                # if self.thinking_spinner_movie and self.thinking_spinner_movie.state() == QMovie.Running:
                #     self.thinking_spinner_movie.stop()
                self.ai_chat_send_button.setText("") # Clear text
                self.ai_chat_send_button.setIcon(self.original_send_button_icon)


        if self.ai_chat_input:
            self.ai_chat_input.setEnabled(can_send_message)
            if can_send_message and self.mw and hasattr(self.mw, 'ai_chatbot_dock') and self.mw.ai_chatbot_dock and self.mw.ai_chatbot_dock.isVisible() and self.mw.isActiveWindow():
                self.ai_chat_input.setFocus()

        if hasattr(self.mw, 'ask_ai_to_generate_fsm_action'):
            self.mw.ask_ai_to_generate_fsm_action.setEnabled(can_send_message)
    
    # ... (rest of AIChatUIManager methods: _format_code_block, _append_to_chat_display, handle_ai_error, etc.)
    # No changes needed to other methods for this specific improvement.
class AIChatbotManager(QObject):
    statusUpdate = pyqtSignal(str)
    errorOccurred = pyqtSignal(str)
    fsmDataReceived = pyqtSignal(dict, str)
    plainResponseReady = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent_window = parent
        self.api_key: str | None = None
        self.chatbot_worker: ChatbotWorker | None = None
        self.chatbot_thread: QThread | None = None
        self.last_fsm_request_description: str | None = None
        logger.info("AIChatbotManager initialized.")

    def _cleanup_existing_worker_and_thread(self):
        logger.debug("MGR_CLEANUP: CALLED.")
        if self.chatbot_thread and self.chatbot_thread.isRunning():
            logger.debug("MGR_CLEANUP: Attempting to quit existing thread...")
            if self.chatbot_worker:
                # Ensure stop_processing_slot is invoked before quitting the thread
                QMetaObject.invokeMethod(self.chatbot_worker, "stop_processing_slot", Qt.BlockingQueuedConnection if QThread.currentThread() != self.chatbot_thread else Qt.DirectConnection)
                logger.debug("MGR_CLEANUP: stop_processing_slot invoked on worker.")

            self.chatbot_thread.quit()
            if not self.chatbot_thread.wait(300): # Increased wait time slightly
                logger.warning("MGR_CLEANUP: Thread did not quit gracefully. Terminating.")
                self.chatbot_thread.terminate()
                self.chatbot_thread.wait(200)
            logger.debug("MGR_CLEANUP: Existing thread stopped.")
        self.chatbot_thread = None

        if self.chatbot_worker:
            logger.debug("MGR_CLEANUP: Disconnecting signals and scheduling old worker for deletion.")
            try: self.chatbot_worker.responseReady.disconnect(self._handle_worker_response)
            except (TypeError, RuntimeError): pass
            try: self.chatbot_worker.errorOccurred.disconnect(self.errorOccurred)
            except (TypeError, RuntimeError): pass
            try: self.chatbot_worker.statusUpdate.disconnect(self.statusUpdate)
            except (TypeError, RuntimeError): pass
            self.chatbot_worker.deleteLater() # Schedule for deletion by the event loop of its thread
            logger.debug("MGR_CLEANUP: Old worker scheduled for deletion.")
        self.chatbot_worker = None
        logger.debug("MGR_CLEANUP: Finished. Worker and thread are None.")


    def set_api_key(self, api_key: str | None):
        old_key_status = 'SET' if self.api_key else 'NONE'
        new_key_status = 'SET' if api_key else 'NONE'
        logger.info(f"MGR_SET_API_KEY (Gemini): New key: '{new_key_status}', Old key: '{old_key_status}'")

        old_api_key_val = self.api_key
        self.api_key = api_key

        # Re-initialize worker if API key changed OR if key is set but worker isn't running
        if old_api_key_val != self.api_key or \
           (self.api_key and (not self.chatbot_worker or not self.chatbot_thread or not self.chatbot_thread.isRunning())):
            self._cleanup_existing_worker_and_thread() # Clean up before setting up new or if key is cleared
            if self.api_key:
                self._setup_worker()
            else:
                self.statusUpdate.emit("Status: Gemini API Key cleared. AI Assistant inactive.")
        elif self.chatbot_worker and self.api_key and self.chatbot_thread and self.chatbot_thread.isRunning():
             # API key value itself might not have changed, but we re-confirm it if called
             # This path is if the key is the same AND worker is running. We tell the worker to re-init its client.
             QMetaObject.invokeMethod(self.chatbot_worker, "set_api_key_slot", Qt.QueuedConnection,
                                      Q_ARG(str, self.api_key))
             self.statusUpdate.emit("Status: Ready. Gemini API Key re-confirmed.")
        elif not self.api_key: # No API key, and no change from previous (was also no key)
            self.statusUpdate.emit("Status: Gemini API Key required.")


    def _setup_worker(self):
        if not self.api_key:
            logger.warning("MGR_SETUP_WORKER: Cannot setup - API key is not set.")
            self.statusUpdate.emit("Status: API Key required.")
            return

        if self.chatbot_worker or (self.chatbot_thread and self.chatbot_thread.isRunning()):
            logger.info("MGR_SETUP_WORKER: Worker/thread exists or is running. Cleaning up first.")
            self._cleanup_existing_worker_and_thread()

        logger.info("MGR_SETUP_WORKER: Setting up new worker and thread.")
        self.chatbot_thread = QThread(self) # Parent 'self' (AIChatbotManager) to manage QThread lifetime
        self.chatbot_worker = ChatbotWorker(self.api_key)
        self.chatbot_worker.moveToThread(self.chatbot_thread)

        self.chatbot_worker.responseReady.connect(self._handle_worker_response)
        self.chatbot_worker.errorOccurred.connect(self.errorOccurred)
        self.chatbot_worker.statusUpdate.connect(self.statusUpdate)

        self.chatbot_thread.start()
        logger.info("MGR_SETUP_WORKER: New AI Chatbot worker thread started.")
        # Initial status update will come from worker after client initialization attempt or from error handling
        # If client init fails in worker, errorOccurred will be emitted. If success, process_message_slot will emit Ready.
        # We can emit an "Initializing" status here, then worker overwrites it.
        self.statusUpdate.emit("Status: AI Assistant Initializing...")


    @pyqtSlot(str, bool)
    def _handle_worker_response(self, ai_response_content: str, was_fsm_generation_attempt: bool):
        logger.info(f"MGR_HANDLE_WORKER_RESPONSE: Received from worker. Was FSM attempt: {was_fsm_generation_attempt}")

        if was_fsm_generation_attempt:
            try:
                cleaned_json_str = ai_response_content
                if ai_response_content.strip().startswith("```json"):
                    cleaned_json_str = ai_response_content.strip()[7:] 
                elif ai_response_content.strip().startswith("```"):
                     cleaned_json_str = ai_response_content.strip()[3:] 
                
                if cleaned_json_str.strip().endswith("```"):
                    cleaned_json_str = cleaned_json_str.strip()[:-3]

                fsm_data = json.loads(cleaned_json_str.strip())
                if isinstance(fsm_data, dict) and ('states' in fsm_data or 'transitions' in fsm_data):
                    logger.info("MGR_HANDLE_WORKER_RESPONSE: Parsed FSM JSON successfully. Emitting fsmDataReceived.")
                    source_desc = self.last_fsm_request_description or "AI Generated FSM"
                    self.fsmDataReceived.emit(fsm_data, source_desc)
                    return 
                else:
                    logger.warning("MGR_HANDLE_WORKER_RESPONSE: JSON parsed but not valid FSM structure. Treating as plain text.")
                    self.errorOccurred.emit("AI returned JSON, but it's not a valid FSM structure. Displaying as text.")
                    # Fall through to plainResponseReady to display the malformed JSON as text.
            except json.JSONDecodeError:
                logger.warning("MGR_HANDLE_WORKER_RESPONSE: Failed to parse AI response as JSON. Treating as plain text.", exc_info=True)
                self.statusUpdate.emit("Status: AI response was not valid FSM JSON.")
                self.errorOccurred.emit(f"AI response for FSM generation was not valid JSON. Raw response (see chat for full):\n{ai_response_content[:200]}...")
                # Fall through to plainResponseReady to display the non-JSON response.

        # If not FSM attempt, or if FSM attempt parsing failed and we want to show the raw response
        logger.debug("MGR_HANDLE_WORKER_RESPONSE: Emitting plainResponseReady.")
        self.plainResponseReady.emit(ai_response_content)


    def _prepare_and_send_to_worker(self, user_message_text: str, is_fsm_gen_specific: bool = False):
        logger.info(f"MGR_PREP_SEND: For: '{user_message_text[:30]}...', FSM_specific_req: {is_fsm_gen_specific}")

        if not self.api_key:
            logger.warning("MGR_PREP_SEND: API Key not set.")
            self.errorOccurred.emit("Gemini API Key not set. Configure in Settings.")
            if self.parent_window and hasattr(self.parent_window, 'ai_chat_ui_manager') and self.parent_window.ai_chat_ui_manager:
                self.parent_window.ai_chat_ui_manager._append_to_chat_display("System Error", "API Key not set.")
            return

        if not self.chatbot_worker or not self.chatbot_thread or not self.chatbot_thread.isRunning():
            logger.warning("MGR_PREP_SEND: Worker/Thread not ready.")
            if self.api_key and (not self.chatbot_thread or not self.chatbot_thread.isRunning()):
                 logger.info("MGR_PREP_SEND: Attempting to re-setup worker because it's not running.")
                 self._setup_worker() # This will setup and start the thread.

            # Check again after attempting setup
            if not self.chatbot_worker or not self.chatbot_thread or not self.chatbot_thread.isRunning():
                self.errorOccurred.emit("AI Assistant is not ready. Please wait or check settings.")
                if self.parent_window and hasattr(self.parent_window, 'ai_chat_ui_manager') and self.parent_window.ai_chat_ui_manager:
                    self.parent_window.ai_chat_ui_manager._append_to_chat_display("System Error", "AI Assistant is not ready.")
                return

        if is_fsm_gen_specific:
            self.last_fsm_request_description = user_message_text
        else:
            self.last_fsm_request_description = None

        diagram_json_str: str | None = None
        if self.parent_window and hasattr(self.parent_window, 'scene') and hasattr(self.parent_window.scene, 'get_diagram_data'):
            try:
                diagram_data = self.parent_window.scene.get_diagram_data()
                lean_diagram_data = {
                    "states": [{"name": s.get("name"), "is_initial": s.get("is_initial"), "is_final": s.get("is_final")} 
                               for s in diagram_data.get("states", [])],
                    "transitions": [{"source": t.get("source"), "target": t.get("target"), "event": t.get("event")}
                                    for t in diagram_data.get("transitions", [])]
                }
                diagram_json_str = json.dumps(lean_diagram_data)
                logger.debug(f"MGR_PREP_SEND: Lean diagram context (first 100 chars): {diagram_json_str[:100]}")
            except Exception as e:
                logger.error(f"MGR_PREP_SEND: Error getting/processing diagram data: {e}", exc_info=True)
                diagram_json_str = json.dumps({"error": "Could not retrieve diagram context."})
        else:
             diagram_json_str = json.dumps({"error": "Diagram context unavailable."})

        if self.chatbot_worker:
            effective_diagram_json_str = diagram_json_str if diagram_json_str is not None else ""
            # Ensure worker is on its thread for these calls
            QMetaObject.invokeMethod(self.chatbot_worker, "set_diagram_context_slot", Qt.QueuedConnection,
                                     Q_ARG(str, effective_diagram_json_str))
            QMetaObject.invokeMethod(self.chatbot_worker, "process_message_slot", Qt.QueuedConnection,
                                     Q_ARG(str, user_message_text),
                                     Q_ARG(bool, is_fsm_gen_specific))
            logger.debug("MGR_PREP_SEND: Methods queued for worker.")
            self.statusUpdate.emit("Status: Sending to AI...")
        else:
            logger.error("MGR_PREP_SEND: Chatbot worker is None, cannot queue methods.")
            self.errorOccurred.emit("AI Assistant encountered an internal error (worker missing). Please try restarting AI features.")

    def send_message(self, user_message_text: str):
        self._prepare_and_send_to_worker(user_message_text, is_fsm_gen_specific=False)

    def generate_fsm_from_description(self, description: str):
         self._prepare_and_send_to_worker(description, is_fsm_gen_specific=True)

    def clear_conversation_history(self):
        logger.info("MGR: clear_conversation_history CALLED.")
        if self.chatbot_worker and self.chatbot_thread and self.chatbot_thread.isRunning():
            QMetaObject.invokeMethod(self.chatbot_worker, "clear_history_slot", Qt.QueuedConnection)
            logger.debug("MGR: clear_history invoked on worker.")
        else:
            self.statusUpdate.emit("Status: Chatbot not active (history is in worker).")
            logger.warning("MGR: Chatbot not active, cannot clear history from worker.")


    def stop_chatbot(self):
        logger.info("MGR_STOP: stop_chatbot CALLED.")
        self._cleanup_existing_worker_and_thread()
        self.statusUpdate.emit("Status: AI Assistant Stopped.")
        logger.info("MGR_STOP: Chatbot stopped and cleaned up.")

    def set_online_status(self, is_online: bool):
        logger.info(f"MGR_NET_STATUS: Online status: {is_online}")
        if self.api_key:
            if is_online:
                if not self.chatbot_thread or not self.chatbot_thread.isRunning():
                    logger.info("MGR_NET_STATUS: Network online, API key present, attempting worker setup.")
                    self._setup_worker() 
                else:
                    # If thread is running, worker should emit its own status.
                    # If it's already ready, this is fine. If it had an error, this might mask it.
                    # Best to let worker status prevail or re-check client status.
                    if self.chatbot_worker and self.chatbot_worker.client:
                        self.statusUpdate.emit("Status: Online and Ready.")
                    elif self.chatbot_worker and not self.chatbot_worker.client:
                         self.statusUpdate.emit("Status: Online, API Key Error.") # Reflect worker's client status
                    else: # Worker not fully instantiated yet
                        self.statusUpdate.emit("Status: Online, Initializing...")


            else: # Offline
                self.statusUpdate.emit("Status: Offline. Gemini AI features unavailable.")
        else: # No API Key
            if is_online:
                self.statusUpdate.emit("Status: Online, Gemini API Key required.")
            else:
                self.statusUpdate.emit("Status: Offline, Gemini API Key required.")
                
                
                
                
                
                